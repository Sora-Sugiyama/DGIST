//
//  main.cpp
//  CSE302
//
//  Created by Sora Sugiyama on 3/17/25.
//

#include <iostream>
#include <vector>
#include <random>
#include "CSE302.h"

int main(int argc, const char * argv[]) {
    auto test=MNIST::readMNIST("MNIST/dataset/t10k-images.idx3-ubyte","MNIST/dataset/t10k-labels.idx1-ubyte");
    auto train=MNIST::readMNIST("MNIST/dataset/train-images.idx3-ubyte","MNIST/dataset/train-labels.idx1-ubyte");

    std::cout<<std::fixed;
    std::cout.precision(4);

    // batch size = 100
    const int batch=6000;
    linAlge::mat X(batch,785),w(785,10),y(batch,10);
    std::vector<linAlge::mat>W={w};

    for(int k=0;k<6000;k+=batch){
        y=linAlge::mat(batch,10);
        for(int i=0;i<batch;i++){
            for(int j=0;j<784;j++)X(i,j)=train[i+k].first[j]/255;
            X(i,784)=1;
            y(i,train[i+k].second)=1;
        }

        std::cout<<"Batch "<<k/batch+1<<", inital loss: "<<model::objFunction::calcMSE(X,W,y,model::actFunction::logistic)<<std::endl;

        optimizer::gradientDescent(
                                   model::objFunction::MSE,
                                   model::objFunction::dMSE,
                                   model::actFunction::logistic,
                                   model::actFunction::dlogistic,
                                   W,
                                   X,
                                   y,
                                   0.05,
                                   200,
                                   1,
                                   model::regularization::dL1,
                                   0.3
                                   );



        std::cout<<"Batch "<<k/batch+1<<", final loss: "<<model::objFunction::calcMSE(X,W,y,model::actFunction::logistic)<<"\n"<<std::endl;
    }

    X=linAlge::mat(10000,785);y=linAlge::mat(10000,10);
    for(int i=0;i<10000;i++){
        for(int j=0;j<784;j++)X(i,j)=test[i].first[j];
        X(i,784)=1;
        y(i,test[i].second)=1;
    }

    std::cout<<"Loss in test data: "<<model::objFunction::calcMSE(X,W,y,model::actFunction::logistic)<<std::endl;

    for(linAlge::mat &ww:W){
        X=X*ww;
    }
    int cnt=0;
    for(int i=0;i<10000;i++){
        double cur=0,mx=-1;
        for(int j=0;j<10;j++){
            if(mx<X(i,j)){
                cur=j;
                mx=X(i,j);
            }
        }
        cnt+=cur==test[i].second;
    }
    std::cout<<"Accuracy: "<<cnt<<"/10000"<<std::endl;
    return 0;
}

