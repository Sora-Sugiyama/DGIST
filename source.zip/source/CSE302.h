//
//  main.cpp
//  CSE302
//
//  Created by Sora Sugiyama on 3/28/25.
//

#ifndef CSE302_h
#define CSE302_h



#include "bmp/bmplot.h"


#include "model/actFunction/logisticAct.h"

#include "model/objFunction/MSE.h"
#include "model/objFunction/cross_entropy.h"

#include "model/regularization/L1L2.h"


#include "linAlge/matrix.h"


#include "optimizer/GA.h"
#include "optimizer/GradientDescent.h"


#include "MNIST/readMNIST.h"



#endif /* CSE302_h */
