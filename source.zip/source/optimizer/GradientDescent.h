//
//  GradientDescent.h
//  CSE302
//
//  Created by Sora Sugiyama on 3/26/25.
//

#ifndef GradientDescent_h
#define GradientDescent_h

#include "../linAlge/matrix.h"
#include <vector>
#include <cstddef>
#include <iostream>
#include <stack>
#include <cmath>
#include <functional>

namespace optimizer{

using u32=uint_fast32_t;


inline const double __no_reg(double lambda,double w){
    return 0;
}

template<
class F,
class DF,
class Act,
class DAct,
class Dreg=std::function<double(double,double)>
>void gradientDescent(
                      F loss,
                      DF dloss,
                      Act actf,
                      DAct dactf,
                      std::vector<linAlge::mat>&coef,
                      linAlge::mat &X,
                      linAlge::mat &Y,
                      const double theta,
                      u32 gn=10000,const u32 &printCur=1<<30,
                      Dreg dreg=__no_reg,const double lambda=0){

    u32 i=0,ii=0,jj=0;

    for(i=1;i<=gn;i++){
        std::stack<linAlge::mat>log;
        linAlge::mat x=X;

        // Forward Prop
        for(linAlge::mat &w:coef){
            log.push(x);
            x=x*w;
            actf(x);
        }

        if((i-1)%printCur==0&&i-1){
            std::cout<<"End of step "<<i-1<<"; loss: "<<loss(x,Y)<<std::endl;
        }

        linAlge::mat h=x;
        x=dloss(x,Y);
        dactf(x,h);


        // Backward Prop
        for(auto it=coef.rbegin();it!=coef.rend();it++){
            linAlge::mat Z=log.top().T(),h=log.top();log.pop();
            linAlge::mat &w=*it;
            linAlge::mat tmp=Z*x;
            for(ii=0;ii<tmp.n;ii++){
                for(jj=0;jj<tmp.m;jj++){
                    w(ii,jj)-=theta*tmp(ii,jj)+theta*lambda*dreg(lambda,w(ii,jj));
                }
            }
            x=x*tmp.T();
            if(it!=coef.rend())dactf(x,h);
        }
    }
}

}

#endif /* GradientDescent_h */
