//
//  main.cpp
//  CSE302
//
//  Created by Sora Sugiyama on 3/28/25.
//

#include <iostream>
#include <vector>
#include <cmath>
#include <random>
#include "CSE302.h"

int main(int argc, const char * argv[]) {

    BMP::fnct_plotter lambda1(0,1,-1.5,1.5,1920,1080);
    BMP::fnct_plotter lambda2(0,1,-1.5,1.5,1920,1080);
    BMP::fnct_plotter lambda3(0,1,-1.5,1.5,1920,1080);
    BMP::fnct_plotter lambda4(0,1,-1.5,1.5,1920,1080);

    // sin(2*pi*x)
    auto fp=[](double x)->double{
        return sin(2*M_PI*x);
    };

    // plot sine function
    lambda1.plotFnct(fp,0,1,2,102,0,153);
    lambda2.plotFnct(fp,0,1,2,102,0,153);
    lambda3.plotFnct(fp,0,1,2,102,0,153);
    lambda4.plotFnct(fp,0,1,2,102,0,153);
    std::vector<std::pair<double,double> >P;

    std::mt19937 gen(2914);
    std::normal_distribution<double> gd{0.0,0.1};

    // 10 points with Gaussian noise
    std::uniform_real_distribution<double>urd(0,1);
    for(int i=0;i<10;i++){
        double x=urd(gen);
        P.push_back({x,fp(x)+gd(gen)});
    }

    // add 2 outliers
    P.push_back({0.2,-0.8});
    P.push_back({0.8,0.8});

    lambda1.plotScatter(P,100,128,128,128);
    lambda2.plotScatter(P,100,128,128,128);
    lambda3.plotScatter(P,100,128,128,128);
    lambda4.plotScatter(P,100,128,128,128);

    std::vector<double>coef;

    double lambda;
    // Define objective function. (In this case, MSE) ;; Add L1 regularization
    auto objf=[&P,&lambda](std::vector<double>&C)->double{
        double ret=0;
        for(auto &p:P){
            double cur=0,x=1;
            for(double &c:C){
                cur+=c*x;
                x*=p.first;
            }
            ret+=(cur-p.second)*(cur-p.second);
        }

        // L2
        for(double &c:C)ret+=lambda*std::abs(c);

        return ret;
    };

    // Set model. (polynomial function)
    auto polyf=[&coef](double x)->double{
        double ret=0,t=1;
        for(auto &c:coef){
            ret+=t*c;
            t*=x;
        }
        return ret;
    };


    std::uniform_real_distribution<double>urd2(-0.01,0.01),urd3(-5,5);
    auto mut=[&gen,&urd2](std::vector<double>&C,const std::vector<double>&sup){
        for(int i=0;i<(int)sup.size();i++){
            C[i]=sup[i]+urd2(gen);
        }
    };


    // initializer for GA
    auto init=[&gen,&urd3](std::vector<std::vector<double> >&Cs){
        for(auto &C:Cs){
            for(auto &c:C)c=urd3(gen);
        }
    };

    // Set color of regression lines
    std::vector<std::vector<int> >colors={
        {255,0,0},
        {0,255,0},
        {0,0,255},
        {255,127,0},
        {0,255,255}
    };


    lambda=0.001;
    auto color=colors.begin();
    for(int k:{1,2,5,9,15}){
        coef.resize(k+1);
        optimizer::GA<std::vector<double>,double>(objf,mut,init,coef);
        lambda1.plotFnct(polyf,0,1,2,(*color)[0],(*color)[1],(*color)[2]);
        color++;
    }

    // plot
    lambda1.plot("figs/","fig1-3-L1-lambda1.bmp");


    lambda=0.005;
    color=colors.begin();
    for(int k:{1,2,5,9,15}){
        coef.resize(k+1);
        optimizer::GA<std::vector<double>,double>(objf,mut,init,coef);
        lambda2.plotFnct(polyf,0,1,2,(*color)[0],(*color)[1],(*color)[2]);
        color++;
    }

    // plot
    lambda2.plot("figs/","fig1-3-L1-lambda2.bmp");


    lambda=0.01;
    color=colors.begin();
    for(int k:{1,2,5,9,15}){
        coef.resize(k+1);
        optimizer::GA<std::vector<double>,double>(objf,mut,init,coef);
        lambda3.plotFnct(polyf,0,1,2,(*color)[0],(*color)[1],(*color)[2]);
        color++;
    }

    // plot
    lambda3.plot("figs/","fig1-3-L1-lambda3.bmp");


    lambda=0.05;
    color=colors.begin();
    for(int k:{1,2,5,9,15}){
        coef.resize(k+1);
        optimizer::GA<std::vector<double>,double>(objf,mut,init,coef);
        lambda4.plotFnct(polyf,0,1,2,(*color)[0],(*color)[1],(*color)[2]);
        color++;
    }

    // plot
    lambda4.plot("figs/","fig1-3-L1-lambda4.bmp");

    return 0;
}

