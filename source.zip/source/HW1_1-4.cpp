//
//  main.cpp
//  CSE302
//
//  Created by Sora Sugiyama on 3/28/25.
//

#include <iostream>
#include <vector>
#include <cmath>
#include <random>
#include "CSE302.h"


int main(int argc, const char * argv[]) {
    BMP::fnct_plotter tmp(0,1,-1.5,1.5,1920,1080);

    // sin(2*pi*x)
    auto fp=[](double x)->double{
        return sin(2*M_PI*x);
    };

    // plot sine function
    tmp.plotFnct(fp,0,1,2,102,0,153);
    std::vector<std::pair<double,double> >P;

    std::mt19937 gen(2914);
    std::normal_distribution<double> gd{0.0,0.1};

    // 100 points with Gaussian noise
    std::uniform_real_distribution<double>urd(0,1);
    for(int i=0;i<100;i++){
        double x=urd(gen);
        P.push_back({x,fp(x)+gd(gen)});
    }

    // add 2 outliers
    P.push_back({0.2,-0.8});
    P.push_back({0.8,0.8});

    tmp.plotScatter(P,100,128,128,128);

    std::vector<double>coef;

    // Define objective function. (In this case, MSE)
    auto objf=[&P](std::vector<double>&C)->double{
        double ret=0;
        for(auto &p:P){
            double cur=0,x=1;
            for(double &c:C){
                cur+=c*x;
                x*=p.first;
            }
            ret+=(cur-p.second)*(cur-p.second);
        }
        return ret;
    };

    // Set model. (polynomial function)
    auto polyf=[&coef](double x)->double{
        double ret=0,t=1;
        for(auto &c:coef){
            ret+=t*c;
            t*=x;
        }
        return ret;
    };


    std::uniform_real_distribution<double>urd2(-0.01,0.01),urd3(-5,5);
    auto mut=[&gen,&urd2](std::vector<double>&C,const std::vector<double>&sup){
        for(int i=0;i<(int)sup.size();i++){
            C[i]=sup[i]+urd2(gen);
        }
    };


    // initializer for GA
    auto init=[&gen,&urd3](std::vector<std::vector<double> >&Cs){
        for(auto &C:Cs){
            for(auto &c:C)c=urd3(gen);
        }
    };

    // plot regression lines
    std::vector<std::vector<int> >colors={
        {255,0,0},
        {0,255,0},
        {0,0,255},
        {255,127,0},
        {0,255,255}
    };

    auto color=colors.begin();
    for(int k:{1,2,5,9,15}){
        coef.resize(k+1);
        optimizer::GA<std::vector<double>,double>(objf,mut,init,coef);
        tmp.plotFnct(polyf,0,1,2,(*color)[0],(*color)[1],(*color)[2]);
        color++;
    }

    // plot bmp
    tmp.plot("figs/","fig1-4.bmp");

    return 0;
}

