//
//  logisticAct.h
//  CSE302
//
//  Created by Sora Sugiyama on 3/26/25.
//

#ifndef logisticAct_h
#define logisticAct_h

#include <cmath>
#include "../../linAlge/matrix.h"


namespace model{

namespace actFunction{

double EXP(double x){
    x=x>50?50:x;
    x=x<-50?-50:x;
    return exp(x);
}

void softmax(linAlge::mat &x){
    int i,j;
    double sum;
    for(i=0;i<x.n;i++){
        sum=0;
        for(j=0;j<x.m;j++){
            x(i,j)=EXP(x(i,j));
            sum+=x(i,j);
        }
        for(j=0;j<x.m;j++)x(i,j)/=sum;
    }
}

void dsoftmax(linAlge::mat &x,linAlge::mat &h){
    int i,j,k;
    linAlge::mat tmp(x.n,x.m);
    for(i=0;i<x.n;i++){
        for(j=0;j<x.m;j++){
            for(k=0;k<x.m;k++){
                if(j==k)tmp(i,j)+=(h(i,j)-h(i,j)*h(i,j))*x(i,k);
                else tmp(i,j)-=h(i,j)*h(i,k)*x(i,k);
            }
        }
    }
    x=tmp;
}

void sigmoid(linAlge::mat &x){
    int i,j;
    for(i=0;i<x.n;i++){
        for(j=0;j<x.m;j++){
            x(i,j)=1/(1+EXP(-x(i,j)));
        }
    }
}

void dsigmoid(linAlge::mat &x,linAlge::mat &h){
    int i,j;
    for(i=0;i<x.n;i++){
        for(j=0;j<x.m;j++){
            double ex=EXP(-h(i,j));
            h(i,j)=ex/(ex*ex+ex+ex+1);
            x(i,j)*=h(i,j);
        }
    }
}


}

}

#endif /* logisticAct_h */
