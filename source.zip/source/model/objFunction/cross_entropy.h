//
//  cross_entropy.h
//  CSE302
//
//  Created by Sora Sugiyama on 3/26/25.
//

#ifndef cross_entropy_h
#define cross_entropy_h

#include "../../linAlge/matrix.h"
#include <cmath>
#include <vector>

namespace model{

namespace objFunction{

using u32=uint_fast32_t;

double CrossEntropy(linAlge::mat &h,linAlge::mat &y){
    u32 i,j;
    double ret=0;

    assert(("Size of h and y is must be equal.\n"&&(h.n==y.n&&h.m==y.m)));
    for(j=0;j<h.m;j++){
        for(i=0;i<h.n;i++){
            ret+=y(i,j)*log(h(i,j)+1e-9);
        }
    }

    return -ret/double(h.n);
}

template<class Act>
double calcCrossEntropy(linAlge::mat X,std::vector<linAlge::mat>&W,linAlge::mat &y,Act actf){
    u32 i,j;
    for(linAlge::mat &w:W){
        X=X*w;
        actf(X);
    }

    return CrossEntropy(X,y);
}

linAlge::mat dCrossEntropy(linAlge::mat &h,linAlge::mat &y){
    u32 i,j;
    linAlge::mat ret(h.n,h.m);
    for(i=0;i<h.n;i++){
        for(j=0;j<h.m;j++){
            ret(i,j)=-y(i,j)/h(i,j)/double(h.n);
        }
    }
    return ret;
}

}

}

#endif /* cross_entropy_h */
