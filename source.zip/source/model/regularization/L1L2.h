//
//  L1L2.h
//  CSE302
//
//  Created by Sora Sugiyama on 3/26/25.
//

#ifndef L1L2_h
#define L1L2_h

#include <cmath>
#include <vector>
#include "../../linAlge/matrix.h"

namespace model{

namespace regularization{

double L1(double loss,std::vector<linAlge::mat> &W,const double lambda=1){
    for(linAlge::mat &w:W){
        for(int i=0;i<w.n;i++){
            for(int j=0;j<w.m;j++)loss+=lambda*abs(w(i,j));
        }
    }
    return loss;
}

double dL1(double lambda,double w){
    return lambda*(w<0?-1:1);
}

double L2(double loss,std::vector<linAlge::mat> &W,const double lambda=1){
    for(linAlge::mat &w:W){
        for(int i=0;i<w.n;i++){
            for(int j=0;j<w.m;j++)loss+=lambda*w(i,j)*w(i,j);
        }
    }
    return loss;
}

double dL2(double lambda,double w){
    return lambda*2*w;
}

}

}

#endif /* L1L2_h */
